﻿
using UnityEngine;
using System;


//  NMath.cs
//  Author: Lu Zexi
//  2013-10-04



namespace NavMesh
{

    /// <summary>
    /// NavMesh专用数学类
    /// </summary>
    public class NMath
    {
        private const float EPSILON = 1e-005f;  //最小常量

        /// <summary>
        /// 将线段终点延长
        /// </summary>
        /// <param name="startPos">起始点</param>
        /// <param name="tarPos">终点</param>
        /// <param name="length">延长长度</param>
        /// <returns></returns>
        public static Vector2 ExtendPos(Vector2 startPos, Vector2 tarPos, int length)
        {
            Vector2 newPos = tarPos;
            float slopeRate = Math.Abs((tarPos.y - startPos.y) / (tarPos.x - startPos.x));
            float xLength, yLength;
            if (slopeRate < 1)
            {
                yLength = length;
                xLength = length / slopeRate;
            }
            else
            {
                xLength = length;
                yLength = length * slopeRate;
            }

            if (tarPos.x > startPos.x)
                newPos.x += xLength;
            else
                newPos.x -= xLength;

            if (tarPos.y > startPos.y)
                newPos.y += yLength;
            else
                newPos.y -= yLength;

            return newPos;
        }

        /// <summary>
        /// 判断矩形是否相交
        /// </summary>
        /// <param name="rec1">矩形1</param>
        /// <param name="rec2">矩形2</param>
        /// <returns>是否相交</returns>
        public static bool CheckCross(Rect rec1, Rect rec2)
        {
            Rect ret = new Rect();
            ret.xMin = Mathf.Max(rec1.xMin, rec2.xMin);
            ret.xMax = Mathf.Min(rec1.xMax, rec2.xMax);
            ret.yMin = Mathf.Max(rec1.yMin, rec2.yMin);
            ret.yMax = Mathf.Min(rec1.yMax, rec2.yMax);

            if (ret.xMin > ret.xMax || ret.yMin > ret.yMax)
            {
                // no intersection, return empty
                return false;
            }
            return true;
        }

        /// <summary>
        /// 根据线段生成矩形
        /// </summary>
        /// <param name="linePath">线段</param>
        /// <returns>矩形</returns>
        public static Rect LineRect(Line2D linePath)
        {
            Rect lineRect = new Rect();

            if (linePath.GetStartPoint().x < linePath.GetEndPoint().x)
                lineRect.xMin = linePath.GetStartPoint().x;
            else
                lineRect.xMin = linePath.GetEndPoint().x;

            if (linePath.GetStartPoint().y < linePath.GetEndPoint().y)
                lineRect.yMin = linePath.GetStartPoint().y;
            else
                lineRect.yMin = linePath.GetEndPoint().y;

            lineRect.width = Math.Abs(linePath.GetEndPoint().x - linePath.GetStartPoint().x);
            lineRect.height = Math.Abs(linePath.GetEndPoint().y - linePath.GetStartPoint().y);

            return lineRect;
        }

        /// <summary>
        /// 检查线段是否相交
        /// </summary>
        /// <param name="sp1">line1 start point</param>
        /// <param name="ep1">line1 end point</param>
        /// <param name="sp2">line2 start point</param>
        /// <param name="ep2">line2 end point</param>
        /// <returns>is cross</returns>
        public static bool CheckCross(Vector2 sp1, Vector2 ep1, Vector2 sp2, Vector2 ep2)
        {
            if (Math.Max(sp1.x, ep1.x) < Math.Min(sp2.x, ep2.x))
            {
                return false;
            }
            if (Math.Min(sp1.x, ep1.x) > Math.Max(sp2.x, ep2.x))
            {
                return false;
            }
            if (Math.Max(sp1.y, ep1.y) < Math.Min(sp2.y, ep2.y))
            {
                return false;
            }
            if (Math.Min(sp1.y, ep1.y) > Math.Max(sp2.y, ep2.y))
            {
                return false;
            }

            float temp1 = CrossProduct((sp1 - sp2), (ep2 - sp2)) * CrossProduct((ep2 - sp2), (ep1 - sp2));
            float temp2 = CrossProduct((sp2 - sp1), (ep1 - sp1)) * CrossProduct((ep1 - sp1), (ep2 - sp1));

            if ((temp1 >= 0) && (temp2 >= 0))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// r=multiply(sp,ep,op),得到(sp-op)*(ep-op)的叉积 
        ///	r>0:ep在矢量opsp的逆时针方向； 
        ///	r=0：opspep三点共线； 
        ///	r<0:ep在矢量opsp的顺时针方向 
        /// </summary>
        /// <param name="p1">opsp</param>
        /// <param name="p2">opep</param>
        /// <returns></returns>
        public static float CrossProduct(Vector2 p1, Vector2 p2)
        {
            return (p1.x * p2.y - p1.y * p2.x);
        }

        /// <summary>
        /// 两个矢量是否相同
        /// </summary>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        /// <returns></returns>
        public static bool IsEqual(Vector2 v1, Vector2 v2)
        {
            return IsEqualZero(v1 - v2);
        }

        /// <summary>
        /// 点是否等于0
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static bool IsEqualZero(Vector2 data)
        {
            if (IsEqualZero(data.x) && IsEqualZero(data.y))
                return true;
            else
                return false;
        }

        /// <summary>
        /// 检查浮点数误差
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static bool IsEqualZero(double data)
        {
            if (Math.Abs(data) <= EPSILON)
                return true;
            else
                return false;
        }
    }
}
