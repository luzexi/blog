﻿


using UnityEngine;
using System.Collections.Generic;


//  Polygon.cs
//  Author: Lu Zexi
//  2013-10-04




namespace NavMesh
{
    /// <summary>
    /// 多边形类
    /// </summary>
    public class Polygon
    {
        private int m_iTag; //标志
        private List<Vector2> m_lstPoints;  //列表点

        public Polygon()
        {
            this.m_lstPoints = new List<Vector2>();
            this.m_iTag = 0;
        }

        public Polygon(List<Vector2> points)
        {
            this.m_lstPoints = points;
            this.m_iTag = 0;
        }

        /// <summary>
        /// 删除重复顶点
        /// </summary>
        /// <returns></returns>
        public void DelRepeatPoint()
        {
            for (int i = 0; i < this.m_lstPoints.Count; i++)
            {
                for (int j = i + 1; j < this.m_lstPoints.Count; j++)
                {
                    if (NMath.IsEqualZero(this.m_lstPoints[i] - this.m_lstPoints[j]))
                    {
                        this.m_lstPoints.Remove(this.m_lstPoints[j]);
                        j = i;
                    }
                }
            }
        }


        /// <summary>
        /// 顺时针排序
        /// </summary>
        /// <returns></returns>
        public void CW()
        {
            if (!IsCW())
            {
                this.m_lstPoints.Reverse();
            }
        }


        /// <summary>
        /// 判断是否是顺时针
        /// </summary>
        /// <returns></returns>
        public bool IsCW()
        {
            if (this.m_lstPoints.Count <= 2)
                return false;

            //最上（y最小）最左（x最小）点， 肯定是一个凸点
            //寻找最上点
            Vector2 topPoint = this.m_lstPoints[0];
            int topIndex = 0;
            for (int i = 1; i < this.m_lstPoints.Count; i++)
            {
                Vector2 currPoint = this.m_lstPoints[i];
                if ((topPoint.y > currPoint.y)
                    || ((topPoint.y == currPoint.y) && (topPoint.x > currPoint.x)))
                {
                    topPoint = currPoint;
                    topIndex = i;
                }
            }

            //寻找左右邻居
            int preIndex = (topIndex - 1) >= 0 ? (topIndex - 1) : (this.m_lstPoints.Count - 1);
            int nextIndex = (topIndex + 1) < this.m_lstPoints.Count ? (topIndex + 1) : 0;

            Vector2 prePoint = this.m_lstPoints[preIndex];
            Vector2 nextPoint = this.m_lstPoints[nextIndex];

            //三点共线情况不存在，若三点共线则说明必有一点的y（斜线）或x（水平线）小于topPt
            float r = NMath.CrossProduct((prePoint - topPoint), (nextPoint - topPoint));
            if (r > 0)
                return true;

            return false;
        }


        /// <summary>
        /// 返回多边形包围盒
        /// </summary>
        /// <returns></returns>
        public Rect GetCoverRect()
        {
            Rect rect = new Rect(0, 0, 0, 0);

            for (int i = 0; i < this.m_lstPoints.Count; i++)
            {
                if (rect.xMin > this.m_lstPoints[i].x)
                    rect.xMin = this.m_lstPoints[i].x;
                if (rect.xMax < this.m_lstPoints[i].x)
                    rect.xMax = this.m_lstPoints[i].x;
                if (rect.yMin > this.m_lstPoints[i].y)
                    rect.yMin = this.m_lstPoints[i].y;
                if (rect.yMax < this.m_lstPoints[i].y)
                    rect.yMax = this.m_lstPoints[i].y;
            }
            return rect;
        }


        /// <summary>
        /// 获取标识
        /// </summary>
        /// <returns></returns>
        public int GetTag()
        {
            return this.m_iTag;
        }

        /// <summary>
        /// 获取点集
        /// </summary>
        /// <returns></returns>
        public List<Vector2> GetPoints()
        {
            return new List<Vector2>(this.m_lstPoints);
        }

        /// <summary>
        /// 增加点位置
        /// </summary>
        /// <param name="pos"></param>
        public void AddPoints(Vector2 pos)
        {
            this.m_lstPoints.Add(pos);
        }

    }

}
